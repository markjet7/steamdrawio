# %%
from ethanol_tutorial import sys 
from steamdrawio import *

# %%

draw(sys)
# %%
