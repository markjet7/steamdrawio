# %%
import sys 
sys.path.append("/Users/mark/Github/steamdrawio/src/steamdrawio/")


from ethanol import sys 
from steamdrawio import *

# %%

draw(sys)
# %%
